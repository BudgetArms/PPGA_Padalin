#include "Globals.h"

Point2f g_StartPosition{ 200, 300 };
Rectf	g_Window{ 0, 0, 10, 10 };


